window.onload = function() {
    nextpage('index.html',true);
};
