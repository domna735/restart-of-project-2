var param = document.currentScript.getAttribute("param");
var hasError = document.currentScript.getAttribute("hasError");
if (hasError == 1) {
    param = escape(param);
    tolocation = "../../../shipment_feeder/feed_print2/main.jsp?upload_err=" + param;
    window.location=tolocation;
} else {
    param = escape(param);
    tolocation = '../../../shipment_feeder/feed_print2/check_data.jsp?param=' + param;
    window.location=tolocation;
}
