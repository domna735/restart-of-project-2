window.onload=function(){
    if (document.getElementById("invalidEmailBackButton")) {
        document.getElementById("invalidEmailBackButton").addEventListener("click", function(){
            history.go(-1);
        });
    }
    if (document.getElementById("backButton")) {
        document.getElementById("backButton").addEventListener("click", function() {
            nextpage('../index.html',false);
        });
    }
}
