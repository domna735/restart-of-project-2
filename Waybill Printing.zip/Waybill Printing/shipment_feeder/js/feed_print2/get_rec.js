var data_arr = document.currentScript.getAttribute("data_arr");
var feed_to = document.currentScript.getAttribute("feed_to");
var awb_filename = document.currentScript.getAttribute("awb_filename");
var clientID = document.currentScript.getAttribute("clientID");
var url = document.currentScript.getAttribute("URL");
var parameterString = document.currentScript.getAttribute("parameterString");

function ajaxFunction() {
  var xmlHttp;
  try {
    // Firefox, Opera 8.0+, Safari
    xmlHttp = new XMLHttpRequest();
  } catch (e) {
    try {
      xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      try {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (e) {
        alert("Your browser does not support AJAX!");
        return false;
      }
    }
  }

  if (feed_to == "awb") {
    //    String awb_filename = UUID.randomUUID().toString().replace("-","");
    //    awb_filename = awb_filename + ".html";
    xmlHttp.onreadystatechange = function () {
      if (xmlHttp.readyState == 4) {
        var server_response = xmlHttp.responseText;
        //check server_response not include "completedcompleted" wording
        //submit to toprint.html, out.println out response
        //else redirect to result html file
        if (server_response.indexOf("Loading Waybill...") != -1) {
          window.location = "../../awb_html/" + awb_filename;
        } else {
          document.write(server_response);
          if (server_response.indexOf("document.show_skip.submit();") == -1) {
            window.open(
              "toprint.jsp?pagefrom=unexpected_error_awb",
              clientID + "_toprint"
            );
          }
        }
      }
    };
  }
  xmlHttp.open("POST", url, true);

  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  //xmlHttp.setRequestHeader("Content-length", parameterString.length);");
  //xmlHttp.setRequestHeader("Connection", "close");");
  xmlHttp.send(parameterString);
}

ajaxFunction();

