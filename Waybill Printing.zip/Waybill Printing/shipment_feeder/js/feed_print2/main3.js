var ps_list_str = document.currentScript.getAttribute("ps_list_str");
var ps_list = JSON.parse(ps_list_str);

function change_value() {
  	
for (var key in ps_list) {
    if (ps_list.hasOwnProperty(key)) {
        var printsetup = ps_list[key];
        sub_grp_id = key;
        awb_copy = printsetup.awb_copy;
        inv_copy = printsetup.inv_copy;
        show_awb_paper_ty = printsetup.show_awb_paper_ty;
        awb_paper_ty = printsetup.awb_paper_ty;
        var sub_grp_id = awb_copy + "|" + inv_copy + "|" + show_awb_paper_ty + "|" + awb_paper_ty;
    }
}

i=document.main.sub_grp_id.selectedIndex;
sel_grp=document.main.sub_grp_id.options[i].value;

sel_grp_val = document.main[sel_grp].value;
console.log(sel_grp);
sel_grp_arr = sel_grp_val.split("|");

document.main.awb_copy.value=sel_grp_arr[0];
document.main.inv_copy.value=sel_grp_arr[1];

if (sel_grp_arr[2] == "Y") {
   document.getElementById("r1").style.visibility="visible";
} else {
   document.getElementById("r1").style.visibility="hidden";
}

if (sel_grp_arr[3] == "A") {
 document.main.awb_paper_ty[0].checked = true;
} else {
   document.main.awb_paper_ty[1].checked = true;
}

}

window.onload=function(){
   document.getElementById("sub_grp_id").addEventListener("change", change_value);
}
