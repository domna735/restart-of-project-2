var head = document.currentScript.getAttribute("head");
var logo = document.currentScript.getAttribute("logo");
var cname = document.currentScript.getAttribute("cname");

loadTop(head, logo, cname);
