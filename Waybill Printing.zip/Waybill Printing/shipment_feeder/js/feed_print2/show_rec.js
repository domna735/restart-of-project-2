var clientID = document.currentScript.getAttribute("clientID");

function toquit() {
  awbpopup = window.open(
    "",
    clientID + "_awb",
    "top=5000,left=5000,width=0,height=0,alwaysLowered=yes"
  );
  awbpopup.close();
  invpopup = window.open(
    "",
    clientID + "_inv",
    "top=5000,left=5000,width=0,height=0,alwaysLowered=yes"
  );
  invpopup.close();
  window.location = "main.jsp";
}

function toupdate() {
  var name_list = "";
  var value_list = "";
  var delimiter = "";
  var err_found = 0;

  //for (i=0; i<document.show_rec.elements.length-24; i++) {
  //for (i=0; i<document.show_rec.elements.length-26; i++) {
  for (i = 0; i < document.show_rec.elements.length - 5; i++) {
    if (containInvalidSymbol(document.show_rec.elements[i].value)) {
      alert(
        "Invalid symbol found at " +
          document.show_rec.elements[i].name +
          ". Please input again."
      );
      document.show_rec.elements[i].focus();
      i = document.show_rec.elements.length - 5;
      err_found = 1;
    } else {
      if (name_list != "") {
        delimiter = ",";
      }
      document.show_rec.elements[i].value = document.show_rec.elements[
        i
      ].value.replace(/"/g, "'");

      name_list += delimiter + document.show_rec.elements[i].name;
      value_list += delimiter + '"' + document.show_rec.elements[i].value + '"';
    }
  }

  if (err_found == 0) {
    document.show_rec.name_list.value = name_list;
    document.show_rec.value_list.value = value_list;
    document.show_rec.submit();
  }
}

function toskip() {
  document.show_rec.action = "skip_rec.jsp";
  document.show_rec.submit();
}

window.onload=function() {
    self.focus();
    document.getElementById("updateButton").addEventListener("click", toupdate);
    document.getElementById("skipButton").addEventListener("click", toskip);
    document.getElementById("quitButton").addEventListener("click", toquit);
    document.show_rec.elements[0].focus();
}


