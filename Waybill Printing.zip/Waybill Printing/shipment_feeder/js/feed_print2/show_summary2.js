var FileName_label = document.currentScript.getAttribute("FileName_label");
var FullFileName_label = document.currentScript.getAttribute("FullFileName_label");

window.open("../../cgi-bin/hkapp/shipment_feeder/download_pdf.cgi?download_filename=" + FileName_label + "&download_file=" + FullFileName_label + "","label");
