var clientID = document.currentScript.getAttribute("clientID");
window.name = clientID + "_toprint";
