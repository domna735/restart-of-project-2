window.onload = function() {
    nextpage('fp_DefPage.jsp',false);
};
