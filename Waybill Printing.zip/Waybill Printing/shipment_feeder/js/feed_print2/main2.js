var err_str = document.currentScript.getAttribute("err_str");
full_err_str = "The following error(s) occured:\n";
full_err_str += err_str;
alert(full_err_str);
