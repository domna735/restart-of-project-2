var clientID = document.currentScript.getAttribute("clientID");
self.focus();

function toback() {;
awbpopup=window.open("", clientID + "_awb","top=5000,left=5000,width=0,height=0,alwaysLowered=yes");
awbpopup.close();
invpopup=window.open("", clientID + "_inv","top=5000,left=5000,width=0,height=0,alwaysLowered=yes");
invpopup.close();
window.location="main.jsp";
};

window.onload=function() {
    document.getElementById("closeButton").addEventListener("click", toback);
}
