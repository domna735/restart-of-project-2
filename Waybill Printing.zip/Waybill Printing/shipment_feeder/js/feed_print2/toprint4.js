var clientID = document.currentScript.getAttribute("clientID");

window.open("", clientID + "_awb", "left=600,top=200,width=400,height=500,toolbar=1,location=1,directories=1,status=1,menubar=1,scrollbars=1,resizable=1");
