function validateForm() {
    var errors = "";
    thisform = document.main;
    
    errors += LimitAttach(thisform.uploadfile.value);
    
    if ((trimAll(thisform.awb_copy.value) == "") || (trimAll(thisform.inv_copy.value) == "")) {
         errors += "Please input the required number of AWB and INV copies.\n"
  } else {
         if ((isNaN(thisform.awb_copy.value)) || (isNaN(thisform.inv_copy.value))) {
         errors += "Please input number of copies in number.\n";
      } else {
         if ((trimAll(thisform.awb_copy.value) == "0") && (trimAll(thisform.inv_copy.value) == "0")) {
             errors += "Please input at least one copy for either AWB or INV.\n";
         }	   	
      }
      
    }
    
    if (errors) {
         err_str = 'The following error(s) occurred:\n'+errors;
        alert(err_str);
      
    } else {
         thisform.awb_copy.value = trimAll(thisform.awb_copy.value);
         thisform.inv_copy.value = trimAll(thisform.inv_copy.value);
    }
    
    return (errors == '');
}


//extArray = new Array(".gif", ".jpg", ".png");
extArray = new Array(".csv");
function LimitAttach(infile) {
allowSubmit = false;
err = "";
if (!infile) {	
   err = "Please select a data file.\n";
 return err;
}

while (infile.indexOf("\\") != -1)
infile = infile.slice(infile.indexOf("\\") + 1);
ext = infile.slice(infile.indexOf(".")).toLowerCase();
for (var i = 0; i < extArray.length; i++) {
if (extArray[i] == ext) { allowSubmit = true; break; }
}

if (!allowSubmit) err = "Please only upload files that end in types:  " + (extArray.join("  ")) + ".\n";

return err;

}

function godownload() {
	document.todownload.sel_sub_grp_id.value=document.main.sub_grp_id.value;
	document.todownload.submit();
}

function godownload_p() {
	document.todownload_p.sel_sub_grp_id.value=document.main.sub_grp_id.value;
	document.todownload_p.default_charset.value=document.main.default_charset.value;
	document.todownload_p.submit();
}

window.onload=function() {
    document.getElementById("mainForm").addEventListener("submit", function() {
        event.preventDefault();
        if (validateForm()) {
            document.getElementById("mainForm").submit();
        }
    });
    document.getElementById("downloadTemplateButton").addEventListener("click", function() {
        godownload();
    });
}
