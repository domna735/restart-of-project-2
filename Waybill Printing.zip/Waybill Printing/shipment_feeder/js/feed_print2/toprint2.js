var awb_filename = document.currentScript.getAttribute("awb_filename");
var clientID = document.currentScript.getAttribute("clientID");''

window.open("../../awb_html/" + awb_filename, clientID + "_awb");
