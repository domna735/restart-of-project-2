document.skip_rec.submit();
