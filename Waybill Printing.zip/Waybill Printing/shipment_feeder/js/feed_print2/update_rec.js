document.update_rec.submit();
