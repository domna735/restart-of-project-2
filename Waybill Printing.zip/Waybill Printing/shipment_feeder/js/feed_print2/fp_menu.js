var menu_lst = document.currentScript.getAttribute("menu_lst");
var df_menu = document.currentScript.getAttribute("df_menu");
loadMenu(menu_lst, df_menu);
