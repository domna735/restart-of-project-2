var inv_filename = document.currentScript.getAttribute("inv_filename");
var clientID = document.currentScript.getAttribute("clientID");

window.open("../../inv_html/" + inv_filename, clientID + "_inv");
