document.getrec.submit();
