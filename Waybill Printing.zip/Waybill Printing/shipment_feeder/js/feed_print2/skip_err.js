document.skip_err.submit();
