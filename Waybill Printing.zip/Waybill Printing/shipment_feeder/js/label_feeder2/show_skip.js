document.show_skip.submit();
