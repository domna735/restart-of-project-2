var airway_no = document.currentScript.getAttribute("airway_no");
window.open("../awb_html/" + airway_no + ".html", "_self", "left=600,top=200,width=400,height=500,toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=1");
